    const fs = require('fs');
    const TelegramBot = require('node-telegram-bot-api');
    const axios = require('axios');
    require('dotenv').config();

    const TOKEN = process.env.BOT_TOKEN;
    const AUTO_API_URL = process.env.AUTO_API_URL || 'http://localhost:3001';
    const ADMIN_ID = process.env.ADMIN_ID ? parseInt(process.env.ADMIN_ID) : null;
    const CHANNEL_ID = process.env.CHANNEL_ID || null;

    if (!TOKEN) { console.error('BOT_TOKEN missing'); process.exit(1); }
    const bot = new TelegramBot(TOKEN);

const express = require('express');
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.json());
app.post(`/api/bot${TOKEN}`, (req, res) => {
  bot.processUpdate(req.body);
  res.sendStatus(200);
});
bot.setWebHook(`${process.env.PUBLIC_URL || 'https://your-vercel-app.vercel.app'}/api/bot${TOKEN}`);

    // basic user persistence
    const USERS_FILE = './users.json';
    function readUsers(){ try { return JSON.parse(fs.readFileSync(USERS_FILE)); } catch(e){ return {}; } }
    function writeUsers(u){ fs.writeFileSync(USERS_FILE, JSON.stringify(u, null,2)); }
    if (!fs.existsSync(USERS_FILE)) writeUsers({});

    function isAdmin(id){ return ADMIN_ID && id === ADMIN_ID; }

    async function grantPremium(userId, grantedBy){
      const users = readUsers();
      users[userId] = users[userId] || {};
      users[userId].premium = true;
      users[userId].since = new Date().toISOString();
      users[userId].grantedBy = grantedBy || 'admin';
      writeUsers(users);
      // DM and channel notify
      try { await bot.sendMessage(userId, '✅ Kamu sekarang PREMIUM!'); } catch(e){}
      if (CHANNEL_ID) {
        await bot.sendMessage(CHANNEL_ID, `🎉 User ${userId} is now PREMIUM.`);
      }
    }

    bot.onText(/\/start/, (msg) => {
      const chatId = msg.chat.id;
      const text = '👋 Selamat! Pilih fitur:';
      const opts = {
        reply_markup: {
          inline_keyboard: [
            [{ text: 'Deploy web → HTTPS', callback_data: 'deployweb' }],
            [{ text: 'HTTPS → .apk', callback_data: 'webtoapk' }],
            [{ text: 'Tiktok → download', callback_data: 'tiktok' }],
            [{ text: 'Brat (sticker)', callback_data: 'brat' }],
            [{ text: 'Generate image', callback_data: 'generate' }],
            [{ text: 'Get code', callback_data: 'getcode' }],
            [{ text: 'Pengumuman', callback_data: 'pengumuman' }],
            [{ text: 'Dapatkan Premium', callback_data: 'getpremium' }]
          ]
        }
      };
      bot.sendMessage(chatId, text, opts);
      // save user
      const users = readUsers();
      users[chatId] = users[chatId] || { id: chatId, username: msg.from.username || null };
      writeUsers(users);
    });

    bot.on('callback_query', (q) => {
      const data = q.data; const chatId = q.message.chat.id;
      bot.answerCallbackQuery(q.id);
      if (data === 'deployweb') bot.sendMessage(chatId, 'Kirim /deployweb <zip_url_or_github_url>');
      if (data === 'webtoapk') bot.sendMessage(chatId, 'Kirim /webtoapk <url>');
      if (data === 'tiktok') bot.sendMessage(chatId, 'Kirim /tiktok <url>');
      if (data === 'brat') bot.sendMessage(chatId, 'Kirim /brat <text>');
      if (data === 'generate') bot.sendMessage(chatId, 'Kirim /generate <deskripsi>');
      if (data === 'getcode') bot.sendMessage(chatId, 'Kirim /getcode <url>');
      if (data === 'pengumuman') {
        if (!isAdmin(q.from.id)) return bot.sendMessage(chatId, 'Hanya admin.');
        bot.sendMessage(chatId, 'Gunakan /pengumuman <text>');
      }
      if (data === 'getpremium') {
        grantPremium(q.from.id, 'self-request').then(()=> bot.sendMessage(chatId, 'Done. Kamu premium (demo).'));
      }
    });

    bot.onText(/\/deployweb (.+)/, async (msg, match) => {
      const url = match[1]; const chatId = msg.chat.id;
      bot.sendMessage(chatId, '🚀 Memulai deploy...');
      try {
        const resp = await axios.post(`${AUTO_API_URL}/deploy`, { url });
        bot.sendMessage(chatId, `✅ Deploy selesai: ${resp.data.deploymentUrl}`);
      } catch (e) { bot.sendMessage(chatId, '❌ Deploy gagal: ' + e.message); }
    });

    bot.onText(/\/webtoapk (.+)/, async (msg, match) => {
      const url = match[1]; const chatId = msg.chat.id;
      bot.sendMessage(chatId, '📦 Memulai konversi ke APK... (bisa memakan waktu)');
      try {
        const resp = await axios.post(`${AUTO_API_URL}/webtoapk`, { url, requester: chatId }, { timeout: 20*60*1000 });
        if (resp.data.apkDownloadUrl) bot.sendMessage(chatId, `✅ APK: ${resp.data.apkDownloadUrl}`);
        else bot.sendMessage(chatId, 'ℹ️ ' + (resp.data.message || 'Tidak ada hasil'));
      } catch (e) { bot.sendMessage(chatId, '❌ WebtoAPK gagal: ' + e.message); }
    });

    bot.onText(/\/tiktok (.+)/, async (msg, match) => {
      const url = match[1]; const chatId = msg.chat.id;
      bot.sendMessage(chatId, '🔎 Mengambil TikTok...');
      try {
        const resp = await axios.post(`${AUTO_API_URL}/tiktok`, { url });
        if (resp.data.playUrl) bot.sendMessage(chatId, `✅ Download: ${resp.data.playUrl}`);
        else bot.sendMessage(chatId, JSON.stringify(resp.data).slice(0,2000));
      } catch (e) { bot.sendMessage(chatId, '❌ Tiktok error: ' + e.message); }
    });

    bot.onText(/\/brat (.+)/, async (msg, match) => {
      const q = match[1]; const chatId = msg.chat.id;
      // simple sticker search via Telegram's sticker sets isn't straightforward, so we return example link
      bot.sendMessage(chatId, `🔎 Mencari sticker untuk: ${q}\n(Hasil demo): https://example.com/sticker/${encodeURIComponent(q)}`);
    });

    bot.onText(/\/generate (.+)/, async (msg, match) => {
      const prompt = match[1]; const chatId = msg.chat.id;
      bot.sendMessage(chatId, '🖼️ Generating...');
      try {
        const resp = await axios.post(`${AUTO_API_URL}/generate`, { prompt }, { responseType: 'arraybuffer', timeout: 120000 });
        const fn = `out-${Date.now()}.png`; fs.writeFileSync(fn, Buffer.from(resp.data)); await bot.sendPhoto(chatId, fn); fs.unlinkSync(fn);
      } catch (e) { bot.sendMessage(chatId, '❌ Generate gagal: ' + e.message); }
    });

    bot.onText(/\/getcode (.+)/, async (msg, match) => {
      const url = match[1]; const chatId = msg.chat.id;
      bot.sendMessage(chatId, '🔎 Mengambil source...');
      try {
        const resp = await axios.post(`${AUTO_API_URL}/getcode`, { url });
        let code = resp.data.code || '';
        if (code.length > 3800) code = code.slice(0,3800) + '\n... (truncated)';
        bot.sendMessage(chatId, `\`\`\`html
${code}
\`\`\``, { parse_mode: 'Markdown' });
      } catch (e) { bot.sendMessage(chatId, '❌ Getcode gagal: ' + e.message); }
    });

    bot.onText(/\/grantpremium (\d+)/, async (msg, match) => {
      if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, 'Hanya admin.');
      const userId = parseInt(match[1]);
      grantPremium(userId, msg.from.id);
      bot.sendMessage(msg.chat.id, '✅ Premium diberikan.');
    });

    bot.onText(/\/pengumuman (.+)/, async (msg, match) => {
      if (!isAdmin(msg.from.id)) return bot.sendMessage(msg.chat.id, 'Hanya admin.');
      const text = match[1];
      const users = readUsers(); const ids = Object.keys(users);
      bot.sendMessage(msg.chat.id, `Mengirim ke ${ids.length} user...`);
      ids.forEach(uid => { try { bot.sendMessage(uid, `📢 PENGUMUMAN:\n\n${text}`); } catch(e){} });
    });

    bot.on('message', (msg) => {
      if (!msg.from) return;
      const users = readUsers(); users[msg.from.id] = users[msg.from.id] || { id: msg.from.id, username: msg.from.username || null }; writeUsers(users);
    });

    console.log('Bot ready.');