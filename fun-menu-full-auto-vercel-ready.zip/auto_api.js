const express = require('express');
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
require('dotenv').config();
const app = express();
app.use(express.json({ limit: '50mb' }));

const PORT = process.env.PORT || 3001;
const VERCEL_TOKEN = process.env.VERCEL_TOKEN;
const VERCEL_TEAM = process.env.VERCEL_TEAM; // optional
const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const GH_OWNER = process.env.GITHUB_ORG_OR_USER;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const CLIPDROP_KEY = process.env.CLIPDROP_KEY;
const RAPIDAPI_KEY = process.env.RAPIDAPI_KEY;
const RAPIDAPI_HOST = process.env.RAPIDAPI_HOST || 'snaptik-free.p.rapidapi.com';

// util
function okJson(res, data){ res.json(data); }

// DEPLOY to Vercel: accepts { url } where url can be zip file or github repo
app.post('/deploy', async (req, res) => {
  const url = req.body.url;
  if (!url) return res.status(400).json({ error: 'url required' });
  if (!VERCEL_TOKEN) return okJson(res, { deploymentUrl: 'https://example.com/mock-deploy', message: 'VERCEL_TOKEN not set - mock response' });
  try {
    // Vercel has a Deployments API: POST https://api.vercel.com/v13/deployments
    // We'll send a simple deployment that points to a repo or uses files upload (complex).
    // Here we assume user passes a GitHub repo url like https://github.com/user/repo
    const body = { name: 'auto-deploy-' + Date.now(), gitSource: { type: 'github', repo: url.replace('https://github.com/','') } };
    const resp = await axios.post('https://api.vercel.com/v13/deployments', body, { headers: { Authorization: `Bearer ${VERCEL_TOKEN}` } });
    return okJson(res, { deploymentUrl: resp.data.url || resp.data.previewUrl || resp.data.aliases?.[0] || resp.data.meta?.githubCommitSha || resp.data });
  } catch (e) {
    console.error('deploy error', e.message);
    return res.status(500).json({ error: e.message });
  }
});

// WEBTOAPK uses GitHub Actions pipeline similar to earlier scaffold approach
app.post('/webtoapk', async (req, res) => {
  const url = req.body.url;
  if (!url) return res.status(400).json({ error: 'url required' });
  if (!GITHUB_TOKEN) return okJson(res, { apkDownloadUrl: `https://example.com/mock-apk/${encodeURIComponent(url)}.zip`, message: 'GITHUB_TOKEN not set - mock response' });
  try {
    // For brevity, we return a message instructing that this feature requires GITHUB_TOKEN configured.
    return okJson(res, { message: 'Web->APK via GitHub Actions is enabled. Ensure GITHUB_TOKEN and GH_OWNER are set in .env on the server.' });
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
});

// TIKTOK via RapidAPI Snaptik (example)
app.post('/tiktok', async (req, res) => {
  const url = req.body.url;
  if (!url) return res.status(400).json({ error: 'url required' });
  if (!RAPIDAPI_KEY) return okJson(res, { playUrl: url, message: 'RAPIDAPI_KEY not set - mock response' });
  try {
    const options = { method: 'GET', url: `https://${RAPIDAPI_HOST}/v1/urls/lookup`, params: { url }, headers: { 'X-RapidAPI-Key': RAPIDAPI_KEY, 'X-RapidAPI-Host': RAPIDAPI_HOST } };
    const resp = await axios.request(options);
    // Structure differs across providers; we pass raw data
    return okJson(res, resp.data);
  } catch (e) {
    console.error('tiktok error', e.message);
    return res.status(500).json({ error: e.message });
  }
});

// GENERATE image: prefer OpenAI, else Clipdrop, else placeholder
app.post('/generate', async (req, res) => {
  const prompt = req.body.prompt || 'No prompt';
  try {
    if (OPENAI_API_KEY) {
      // OpenAI Images API: POST https://api.openai.com/v1/images/generations
      const resp = await axios.post('https://api.openai.com/v1/images/generations', { prompt, n:1, size: '1024x1024' }, { headers: { Authorization: `Bearer ${OPENAI_API_KEY}` } , responseType: 'json' });
      // resp.data.data[0].b64_json or resp.data.data[0].url depending on model; many models return b64
      if (resp.data && resp.data.data && resp.data.data[0] && resp.data.data[0].b64_json) {
        const b64 = resp.data.data[0].b64_json;
        const buf = Buffer.from(b64, 'base64');
        res.set('Content-Type','image/png'); return res.send(buf);
      }
      if (resp.data && resp.data.data && resp.data.data[0] && resp.data.data[0].url) {
        // fetch url and pipe
        const imageResp = await axios.get(resp.data.data[0].url, { responseType: 'arraybuffer' });
        res.set('Content-Type','image/png'); return res.send(Buffer.from(imageResp.data));
      }
      return res.status(500).json({ error: 'Unexpected OpenAI response' });
    } else if (CLIPDROP_KEY) {
      const FormData = require('form-data');
      const form = new FormData();
      form.append('prompt', prompt);
      const resp = await axios.post('https://clipdrop-api.co/text-to-image/v1', form, { headers: { 'x-api-key': CLIPDROP_KEY, ...form.getHeaders() }, responseType: 'arraybuffer' });
      res.set('Content-Type','image/png'); return res.send(Buffer.from(resp.data));
    } else {
      // placeholder 1x1 png
      const placeholder = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVQYV2NgYAAAAAMAASsJTYQAAAAASUVORK5CYII=', 'base64');
      res.set('Content-Type','image/png'); return res.send(placeholder);
    }
  } catch (e) {
    console.error('generate error', e.message);
    return res.status(500).json({ error: e.message });
  }
});

// GETCODE - server-side fetch
app.post('/getcode', async (req, res) => {
  const url = req.body.url;
  if (!url) return res.status(400).json({ error: 'url required' });
  try {
    const resp = await axios.get(url, { timeout: 15000 });
    return okJson(res, { code: resp.data });
  } catch (e) {
    console.error('getcode error', e.message);
    return res.status(500).json({ error: e.message });
  }
});

app.listen(PORT, () => console.log('Auto API listening on', PORT));