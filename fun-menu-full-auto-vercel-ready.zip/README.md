Fun Menu - Full Automatic (Bot + Auto API)
-----------------------------------------
Paket ini berisi proyek siap pakai dengan fitur lengkap otomatis (jika kamu isi API keys di .env):

Fitur otomatis (kalau kunci ada):
- /deployweb <zip_or_github_url>  -> deploy ke Vercel via VERCEL_TOKEN
- /webtoapk <url>                 -> buat APK via GitHub Actions (requires GITHUB_TOKEN)
- /tiktok <url>                   -> download TikTok via RapidAPI SnapTik (RAPIDAPI_KEY)
- /brat <text>                    -> cari sticker via Telegram (stub + example)
- /generate <prompt>              -> generate image via OpenAI Images API (OPENAI_API_KEY) or Clipdrop (CLIPDROP_KEY)
- /getcode <url>                  -> fetch source server-side
- /pengumuman <text>              -> broadcast to all users (admin)
- Premium system with auto-notify to channel

How to use:
1. Copy .env.example -> .env and fill keys you have (BOT_TOKEN, VERCEL_TOKEN, GITHUB_TOKEN, OPENAI_API_KEY, RAPIDAPI_KEY, ADMIN_ID, CHANNEL_ID, GITHUB_ORG_OR_USER)
2. npm install
3. Run locally: node auto_api.js & node bot.js
4. Or deploy auto_api.js and bot as webhook to Vercel (see README for notes)

Notes:
- Some APIs require paid plans or have rate limits. If a key is not provided, auto_api returns mocked responses so you can test.
- For production, secure your keys with Vercel environment variables or other secret managers.
